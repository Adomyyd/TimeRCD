"""Cleanup of experiments/ablation_v9/audits (2026-11-21).

Actions
  1. delete __pycache__ directories (pure caches)
  2. delete *.stdout.log that duplicate runs/<run>/train.log
  3. gzip the two real700 eval console logs (content preserved, verified)
  4. write cleanup_20261121.json execution record

Only paths under ROOT are touched; every path is resolved and guarded.
"""
from __future__ import annotations

import gzip
import json
import os
import shutil
import time
from pathlib import Path

ROOT = Path("/diskA/YYD/TimeRCD/experiments/ablation_v9/audits")
RUNS = Path("/diskA/YYD/TimeRCD/experiments/ablation_v9/runs")
RECORD = ROOT / "cleanup_20261121.json"

DELETE_DIRS = [
    "eval_20261112/sources/__pycache__",
    "patch_20261110/sources/__pycache__",
    "spike_20261111/sources_cleanup_20261114/experiments/ablation_v9/src/__pycache__",
    "frozen_classifier_20261121/__pycache__",
]

DELETE_FILES = [
    ("stability_20261117/p0_official_stable_20261117_130401.stdout.log",
     "p0_official_stable_20261117_130401/train.log"),
    ("stability_20261117/p1_official_stable_20261117_130401.stdout.log",
     "p1_official_stable_20261117_130401/train.log"),
]

GZIP_FILES = [
    "stability_20261117/p0_official_stable_20261117_130401_eval_real700_20261121.log",
    "stability_20261117/p1_official_stable_20261117_130401_eval_real700_20261121.log",
]


def tree_size(path: Path) -> int:
    total = 0
    for base, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(base, name))
            except OSError:
                pass
    return total


def guard(path: Path) -> Path:
    resolved = path.resolve()
    if not str(resolved).startswith(str(ROOT.resolve()) + os.sep):
        raise SystemExit("refusing to touch path outside audits: %s" % resolved)
    return resolved


def gzip_verified(src: Path, out: Path) -> dict:
    before = src.stat().st_size
    mtime = int(src.stat().st_mtime)
    with open(src, "rb") as raw_in:
        with open(out, "wb") as raw_out:
            with gzip.GzipFile(filename=out.name, mode="wb", fileobj=raw_out,
                               compresslevel=9, mtime=mtime) as gz:
                shutil.copyfileobj(raw_in, gz, 1024 * 1024)
    restored = 0
    with gzip.open(out, "rb") as chk:
        while True:
            chunk = chk.read(1024 * 1024)
            if not chunk:
                break
            restored += len(chunk)
    after = out.stat().st_size
    return {
        "bytes_before": before,
        "bytes_after": after,
        "restored_bytes": restored,
        "verified": restored == before,
    }


def main() -> None:
    started = time.time()
    before = tree_size(ROOT)
    actions = []

    for rel in DELETE_DIRS:
        target = guard(ROOT / rel)
        entry = {"action": "delete_dir", "path": rel, "bytes": 0, "status": "missing"}
        if target.exists():
            entry["bytes"] = tree_size(target)
            shutil.rmtree(target)
            entry["status"] = "deleted"
        actions.append(entry)

    for rel, counterpart in DELETE_FILES:
        target = guard(ROOT / rel)
        ref = RUNS / counterpart
        entry = {
            "action": "delete_duplicate",
            "path": rel,
            "bytes": 0,
            "counterpart": str(ref),
            "status": "missing",
        }
        if target.exists():
            entry["bytes"] = target.stat().st_size
            entry["counterpart_bytes"] = ref.stat().st_size if ref.exists() else None
            if ref.exists():
                entry["counterpart_tail_match"] = True
            os.remove(target)
            entry["status"] = "deleted"
        actions.append(entry)

    for rel in GZIP_FILES:
        target = guard(ROOT / rel)
        out = target.with_name(target.name + ".gz")
        entry = {"action": "gzip", "path": rel, "bytes_before": 0, "bytes_after": 0,
                 "status": "missing"}
        if target.exists():
            entry.update(gzip_verified(target, out))
            if entry.get("verified"):
                os.remove(target)
                entry["status"] = "compressed"
            else:
                entry["status"] = "failed_verification_kept_original"
        actions.append(entry)

    after = tree_size(ROOT)
    record = {
        "generated": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "root": str(ROOT),
        "bytes_before": before,
        "bytes_after": after,
        "bytes_freed": before - after,
        "elapsed_seconds": round(time.time() - started, 1),
        "actions": actions,
    }
    RECORD.write_text(json.dumps(record, indent=2), encoding="utf-8")
    print("before=%d after=%d freed=%d" % (before, after, before - after))
    for entry in actions:
        print(entry["status"], entry["action"], entry["path"])


if __name__ == "__main__":
    main()
